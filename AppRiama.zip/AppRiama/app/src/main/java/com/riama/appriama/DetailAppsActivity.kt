package com.riama.appriama

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailAppsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_apps)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val apps = intent.getParcelableExtra<Apps>(MainActivity.INTENT_PARCELABLE)

        val imgApps = findViewById<ImageView>(R.id.img_item_photo)
        val nameApps = findViewById<TextView>(R.id.tv_item_name)
        val descApps = findViewById<TextView>(R.id.tv_item_description)

        imgApps.setImageResource(apps?.imgApps!!)
        nameApps.text = apps.nameApps
        descApps.text = apps.descApps
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}