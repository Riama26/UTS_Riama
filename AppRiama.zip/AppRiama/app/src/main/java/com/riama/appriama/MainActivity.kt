package com.riama.appriama

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val appsList = listOf<Apps>(
            Apps(
                R.drawable.photoshop,
                "Adobe Photoshop",
                "Adobe Photoshop, atau biasa disebut Photoshop, adalah perangkat lunak editor " +
                        "citra buatan Adobe Systems yang dikhususkan untuk pengeditan foto/gambar dan pembuatan efek."),

            Apps(
                R.drawable.ae,
                "Adobe After Effects",
                "Adobe After Effects adalah produk peranti lunak yang dikembangkan oleh Adobe, " +
                        "digunakan untuk film dan pos produksi pada video. Pada awalnya merupakan sebuah software " +
                        "produk dari Macromedia yang sekarang sudah menjadi salah satu produk Adobe."),

            Apps(
                R.drawable.ai,
                "Adobe Illustrator",
                "Adobe Illustrator adalah program editor grafis vektor terkemuka, dikembangkan dan dipasarkan oleh Adobe Systems. " +
                        "Illustrator CC merupakan versi terkini program ini, generasi kedua puluh untuk produk Illustrator."),

            Apps(
                R.drawable.pr,
                "Adobe Premiere",
                "Adobe Premiere Pro adalah perangkat lunak penyunting video yang dikhususkan " +
                        "untuk membuat rangkaian gambar, audio dan video."),

            Apps(
                R.drawable.an,
                "Adobe Animate",
                "Adobe Animate adalah multimedia yang berguna untuk membuat animasi dari Adobe Inc. " +
                        "Adobe Animate digunakan untuk merancang grafik vektor dan animasi untuk " +
                        "program televisi, video online, situs web, aplikasi web, aplikasi internet yang kaya, dan permainan video."),

            Apps(
                R.drawable.dw,
                "Adobe Dreamweaver",
                "Adobe Dreamweaver merupakan program penyunting halaman web keluaran Adobe Systems " +
                        "yang dulu dikenal sebagai Macromedia Dreamweaver keluaran Macromedia. " +
                        "Program ini banyak digunakan oleh pengembang web karena fitur-fiturnya yang menarik dan kemudahan penggunaannya"),

            Apps(
                R.drawable.corel,
                "CorelDraw",
                "CorelDraw adalah perangkat lunak yang digunakan untuk membuat gambar atau desain dengan basis vector. " +
                        "Software ini memiliki banyak kegunaan dalam urusan grafis seperti, membuat sketsa, gambar, logo, hingga desain arsitektur."),

            Apps(
                R.drawable.unity,
                "Unity",
                "Unity 3D adalah sebuah salah game engine terbaik yang dikembangkan oleh Unity Technologies " +
                        "dan bersifat cross-platform, artinya anda dapat membuat serta merilis game kita ke berbagai platform terkenal, " +
                        "seperti Windows, Linux, Mac OS, Android, iOs, PS3, PS4, Xbox One, dan lain-lain."),

            Apps(
                R.drawable.unreal,
                "Unreal Engine",
                "Unreal Engine adalah sebuah aplikasi pengembangan permainan yang dibuat oleh Epic Games, " +
                        "memulai debutnya pada 1998, dengan permainan bertema tembak-menembak orang-pertama."),

            Apps(
                R.drawable.alice,
                "Alice",
                "Alice adalah sebuah lingkungan pemrograman 3D yang inovatif yang memudahkan untuk membuat animasi untuk bercerita, memainkan permainan interaktif, atau video. " +
                        "Alice adalah alat pengajaran open source yang dirancang untuk menjadi paparan pertama siswa untuk pemrograman berorientasi obyek."),
        )

        val recyclerView = findViewById<RecyclerView>(R.id.rv_apps)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = AppsAdapter(this, appsList){

            val intent = Intent (this,DetailAppsActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)

        }
    }
}