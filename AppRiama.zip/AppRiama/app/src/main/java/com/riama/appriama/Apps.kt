package com.riama.appriama

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Apps(
    val imgApps: Int,
    val nameApps: String,
    val descApps: String

) : Parcelable
