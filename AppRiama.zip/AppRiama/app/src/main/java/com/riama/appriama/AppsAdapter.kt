package com.riama.appriama

import android.content.Context
import android.location.GnssAntennaInfo
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class AppsAdapter(private val context: Context, private val apps: List<Apps>, val listener: (Apps) -> Unit)
    : RecyclerView.Adapter<AppsAdapter.AppsViewHolder>(){

    class AppsViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val imgApps = view.findViewById<ImageView>(R.id.img_item_photo)
        val nameApps = view.findViewById<TextView>(R.id.tv_item_name)
        val descApps = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(apps: Apps, listener: (Apps) -> Unit){
            imgApps.setImageResource(apps.imgApps)
            nameApps.text = apps.nameApps
            descApps.text = apps.descApps

            itemView.setOnClickListener{
                listener (apps)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppsViewHolder {
        return AppsViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        )
    }

    override fun onBindViewHolder(holder: AppsViewHolder, position: Int) {
        holder.bindView(apps[position], listener)
    }

    override fun getItemCount(): Int = apps.size

}
